package com.otak.editor;

public interface CodeChangedListener {
    public void codeChanged();
}
