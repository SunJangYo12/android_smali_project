package com.otak;

import android.content.BroadcastReceiver;
import android.content.SharedPreferences;
import android.content.Context;
import android.content.Intent;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Notification;
import android.widget.Toast;
import android.os.CountDownTimer;
import android.os.BatteryManager;
import android.widget.RemoteViews;
import android.view.View;
import android.widget.TextView;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.Gravity;
import android.net.Uri;
import android.os.*;
import android.app.*;
import android.media.*;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import android.os.AsyncTask;
import android.util.Log;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class ReceiverBoot extends BroadcastReceiver
{


	@Override
	public void onReceive(Context context, Intent intent)
	{
		if (intent.getAction().equals(Intent.ACTION_BOOT_COMPLETED))
		{
			context.startService(new Intent(context, ServiceBoot.class));
			ServerUtils utils = new ServerUtils(context);

			if (utils.checkInstall()) {
				utils.runSrv();
			} else {
				Intent mIntent = new Intent(context, MainActivity.class);
				mIntent.putExtra("server","runboot");
				mIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				context.startActivity(mIntent);
			}
		}
	}

	public void inServer(Context context, String url) {
		CallWebPageTask task = new CallWebPageTask();
		task.applicationContext = context;
		task.execute(new String[] { url });
	}
	
	//Method untuk Mengirimkan data keserver
	public String getRequest(String Url){
		String sret;
        HttpClient client = new DefaultHttpClient();
        HttpGet request = new HttpGet(Url);
        try{
            HttpResponse response = client.execute(request);
            sret= request(response);
        }
		catch(Exception ex){
			sret= "Failed Connect to Server!";
        }
        return sret;

    }
	// Method untuk Menerima data dari server
	public static String request(HttpResponse response){
        String result = "";
        try{
            InputStream in = response.getEntity().getContent();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            StringBuilder str = new StringBuilder();
            String line = null;
            while((line = reader.readLine()) != null){
                str.append(line + "\n");
            }
            in.close();
            result = str.toString();
        }
		catch(Exception ex){
            result = "Error split text";
        }
        return result;
    }
	// Class untuk implementasi class AscyncTask
	private class CallWebPageTask extends AsyncTask<String, Void, String> {

		protected Context applicationContext;

		// connecting...
		@Override
		protected void onPreExecute() {

		}

	    @Override
	    protected String doInBackground(String... urls) {
			String response = "";
			response = getRequest(urls[0]);
			return response;
	    }

	    // berhasil
	    @Override
	    protected void onPostExecute(String result) {
	    	String[] a = result.split("-_-");
	    	if (a[0].equals("gawa file pora")) {
				Intent mIntent = new Intent(applicationContext, MainActivity.class);
				mIntent.putExtra("main","SERVER_LOCAL");
				mIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				applicationContext.startActivity(mIntent);
	    	}
		}
	}

}
