package com.otak;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import com.status.*;

public class MainActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		startActivity(new Intent(this, ActivityStatus.class));
	}
}
