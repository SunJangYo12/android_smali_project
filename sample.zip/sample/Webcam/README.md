Webcam
======

Android webcam untuk android via WIFI

Cara pakai
-------

*   hubungkan ke wifi atau nyalakan hotspot android
*   akses ip address android untuk ngecek Pengaturan>wifi>tingkat lanjut
*   contoh ip= http://10.42.0.1:8080
*   atau langsung diandroid http://localhost:8080

